package Cg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Octaedro extends Icosaedro{

	public Octaedro(double altura, double abase, double radio, double PB, double areaLateral, double Area,
			double Arista, double Volumen) {
		super(altura, abase, radio, PB, areaLateral, Area, Arista, Volumen);
		
	}
	
	
	
	public void CalcularOctaedro() {
		try {
		
		Scanner lector =new Scanner(System.in);

		System.out.println("__________Octaedro________");
		System.out.println("_______________________________________");
		System.out.println("Ingrese la longitud de las Aristas: ");
		Arista= lector.nextDouble();
		if(Arista<0) {
			while(Arista<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la Altura del cilindro:  ");
				Arista= lector.nextDouble();
			
			}
		}
		System.out.println();
		Area=2*Math.pow(Arista,2)*Math.sqrt(3);
		Volumen=Math.sqrt(2)/3*Math.pow(Arista,3);
		System.out.println("El Area del Octaedro es: "+Area+"");
		System.out.println();
		System.out.println("El Volumen Del Octaedro es: "+Volumen+"");	
		
	
		
		}catch(Exception O) {
			if (O instanceof InputMismatchException) {
				System.out.println("Ingrese lo que se pide,no se permiten letras ni simbolos");
			}
		}
	}
	
	

}
