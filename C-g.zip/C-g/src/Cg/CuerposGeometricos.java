package Cg;

public class CuerposGeometricos {
	protected double altura;
	private int lados;
	private double Abase;
	protected double radio;
	public double PB;
	public double  AreaLateral;
	public double Area;
	protected double Volumen;
	
	public CuerposGeometricos(double altura, double abase, double radio, double PB, double areaLateral,double Area) {
		
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public int getLados() {
		return lados;
	}

	public void setLados(int lados) {
		this.lados = lados;
	}

	public double getAbase() {
		return Abase;
	}

	public void setAbase(double abase) {
		Abase = abase;
	}

	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}

	public double getPB() {
		return PB;
	}

	public void setPB(double pB) {
		PB = pB;
	}

	public double getAreaLateral() {
		return AreaLateral;
	}

	public void setAreaLateral(double areaLateral) {
		AreaLateral = areaLateral;
	}

	public double getArea() {
		return Area;
	}

	public void setArea(double area) {
		Area = area;
	}

	public double getVolumen() {
		return Volumen;
	}

	public void setVolumen(double volumen) {
		Volumen = volumen;
	}
	
	
	
	
	
	
}

	////
	////
	/////
	
	
	
	
	
	
	
	
	
	
