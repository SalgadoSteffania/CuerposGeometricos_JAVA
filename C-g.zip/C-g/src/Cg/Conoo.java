package Cg;

import java.util.Scanner;

public class Conoo extends CuerposGeometricos {
 protected double Generatriz;
 protected double Altura;
 
	public Conoo(double altura, double abase, double radio, double PB, double areaLateral, double area,double Generatriz,double Altura) {
		super(altura, abase, radio, PB, areaLateral, area);
		this.Altura=Altura;
		this.Generatriz=Generatriz;
		
	}
	
	public double getGeneratriz() {
		return Generatriz;
	}
	public void setGeneratriz(double generatriz) {
		Generatriz = generatriz;
	}
	public double getAltura() {
		return Altura;
	}
	public void setAltura(double altura) {
		Altura = altura;
	}
	
/*METODOS*/
	
	public void CalcularCono() {
Scanner lector = new Scanner (System.in);
try {
		
		double AreaLateral,AreaTotal,Volumen,radio;
		double Altura,Generatriz;
		System.out.println("______Cono______");
		System.out.println("Ingrese el radio del cono");
		radio= lector.nextDouble();
		if(radio<0) {
			while(radio<0) {
				System.out.println("No puede ingresar datos negativos");	
				System.out.println("Ingrese el radio del c:  ");
				radio = lector.nextDouble();
			}
		}
		System.out.println("Ingrese la ALtura del cono");
		Altura= lector.nextDouble();
		if(Altura<0) {
			while(Altura<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la Altura del cilindro:  ");
				Altura= lector.nextDouble();
			}
		}
		Generatriz=Math.sqrt( Math.pow(Altura,2)+Math.pow(radio,2));
		AreaLateral=Math.PI*radio*Generatriz;
		AreaTotal=Math.PI*radio*(Generatriz+radio);
		Volumen= (Math.PI*Math.pow(radio,2)*Altura)/3;
		
		
	System.out.println("El Area Lateral Del Cono es: "+AreaLateral+"");
	System.out.println("El Area Total Del Cono es: "+AreaTotal+"");
	System.out.println("El Volumen Del Cono es: "+Volumen+"");
	System.out.println("La Generatriz Del Cono es: "+Generatriz+"");
    }catch (Exception o) {
		//System.out.println(o.toString());
		System.out.println("No puede ingresar letras ni simbolos");
		System.out.println("Vuelva a intentarlo");
	}
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
