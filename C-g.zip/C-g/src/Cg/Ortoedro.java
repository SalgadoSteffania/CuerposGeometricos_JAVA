package Cg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Ortoedro extends Octaedro {
 private double a;
 private double b;
 private double c;
 private double Diagonal;
	public Ortoedro(double altura, double abase, double radio, double PB, double areaLateral, double Area,
			double Arista, double Volumen,double a,double b,double c,double Diagonal) {
		
		super(altura, abase, radio, PB, areaLateral, Area, Arista, Volumen);
		this.a=a;
		this.b=b;
		this.c=c;
		this.Diagonal=Diagonal;
		
	}
	public double getA() {
		return a;
	}
	public void setA(double a) {
		this.a = a;
	}
	public double getB() {
		return b;
	}
	public void setB(double b) {
		this.b = b;
	}
	public double getC() {
		return c;
	}
	public void setC(double c) {
		this.c = c;
	}
	public double getDiagonal() {
		return Diagonal;
	}
	public void setDiagonal(double diagonal) {
		Diagonal = diagonal;
	}
	//////
	////////////////
	
	public void CalcularOrtoedro() {
		try {
		
		Scanner lector=new Scanner(System.in);
		
		System.out.println("_____Ortoedro_____");
		System.out.println("_____________________________________");
		System.out.println("Ingrese la longitud de la Arista a= ");
		a= lector.nextDouble();
		if(a<0) {
			while(a<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud de la arista a:  ");
				a= lector.nextDouble();
			}
		}
		System.out.println("Ingrese la longitud de la Arista b= ");
		b= lector.nextDouble();
		if(b<0) {
			while(b<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud de la arista b:  ");
				b= lector.nextDouble();
			}
		}
		System.out.println("Ingrese la longitud de la Arista c= ");
		c= lector.nextDouble();
		if(c<0) {
			while(c<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud de la arista c:  ");
				c= lector.nextDouble();
			}
		}
		Area=2*(a*b+a*c+b*c);
		Volumen= a*b*c;
		Diagonal=Math.sqrt(Math.pow(a,2)+Math.pow(b,2)+Math.pow(c,2));
		
		System.out.println("El Area del Ortoedro es:  "+Area+"");
		System.out.println("������������������������������������������������");
		System.out.println("El Volumen del Ortoedro es:  "+Volumen+"");
		System.out.println("������������������������������������������������");
		System.out.println("La Diagonal del Ortoedro es:  "+Diagonal+"");
		

		
		}catch(Exception Ort) {
			if ( Ort instanceof InputMismatchException) {
				System.out.println("Error ha ingresado valores no permitidos");
			}
		}
		
	}

}
