package Cg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class HusoEsf extends CuerposGeometricos{
  private double NumeroDeGrado;
  private double Volumen;
  public double Area;
	
	
	
	public HusoEsf(double altura, double abase, double radio, double PB, double areaLateral, double Area, double NumeroDeGrado,double Volumen) {
		super(altura, abase, radio, PB, areaLateral, Area);
		this.NumeroDeGrado=NumeroDeGrado;
		this.Volumen=Volumen;
		this.Area=Area;
		
	}


	/////
	///////////
	
	public double getNumeroDeGrado() {
		return NumeroDeGrado;
	}





	public void setNumeroDeGrado(double numeroDeGrado) {
		NumeroDeGrado = numeroDeGrado;
	}





	public double getVolumen() {
		return Volumen;
	}





	public void setVolumen(double volumen) {
		Volumen = volumen;
	}





	public double getArea() {
		return Area;
	}





	public void setArea(double area) {
		Area = area;
	}





	public void CalcularHusoEsferico() {
		try {
		
		Scanner lector=new Scanner(System.in);
		System.out.println("______Huso Esferico_____");
		System.out.println("__________________________________");
		System.out.println("Ingrese la longitud del Radio: ");
		radio= lector.nextDouble();
		if(radio<0) {
			while(radio<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud del Radio :  ");
				radio= lector.nextDouble();
			}
		}
		System.out.println("Ingrese el numero de grados: ");
		NumeroDeGrado= lector.nextDouble();
		if(NumeroDeGrado<0) {
			while(NumeroDeGrado<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese el numero de grados:  ");
				NumeroDeGrado= lector.nextDouble();
			}
		}
		Area= (4*Math.PI*Math.pow(radio, 2)*NumeroDeGrado)/360;
		//cu�a esferica
		Volumen=4*((Math.PI*Math.pow(radio,3)*NumeroDeGrado)/360)/3;
		
		System.out.println("El Area de Huso Esferico es: "+Area+"");
		System.out.println();
		System.out.println("El Volumen de Cu�a Esferica es: "+Volumen+"");
		
		}catch(Exception HEs) {
			if (HEs instanceof InputMismatchException) {
				System.out.println("No ingrese letras ni simbolos");
			}
			
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
