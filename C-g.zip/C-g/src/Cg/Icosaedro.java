package Cg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Icosaedro extends Tetraedro{


	
	public Icosaedro(double altura, double abase, double radio, double PB, double areaLateral, double Area,
			double Arista, double Volumen) {
		super(altura, abase, radio, PB, areaLateral, Area, Arista, Volumen);

	}
	

	public void CalcularIcosaedro() {
		try {
		Scanner lector = new Scanner (System.in); 
			System.out.println("Icosaedro:20 Triangulos Equilateros");
			System.out.println("Ingrese la longitud de las Aristas: ");
			Arista = lector.nextDouble();
			Area=5*Math.pow(Arista,2)*Math.sqrt(3);
			Volumen= (3+Math.sqrt(5))*(Math.pow(Arista,3))*5/12;
			System.out.println("El Area del Icosaedro es: "+Area+"");
			System.out.println("El volumen del Icosaedro es:  "+Volumen+"");	
				
		}catch(Exception IC) {
			if (IC instanceof InputMismatchException) {
				System.out.println("No puede ingresasr letras ni simbolos");
			}
		}
	}
	
	
	
	
	

}
