package Cg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Tetraedro extends CuerposGeometricos {
protected double Arista;
	protected double Volumen;
	
	
	public Tetraedro(double altura, double abase, double radio, double PB, double areaLateral, double Area,double Arista,double Volumen) {
		super(altura, abase, radio, PB, areaLateral, Area);
		this.Arista=Arista;
		this.Volumen=Volumen;
		
		
	}

	
	public void CalcularTetraedro() {
		try {
		
		Scanner lector=new Scanner(System.in);
		
		System.out.println("_____Tetraedro_____");
		System.out.println("_____________________________________");
		System.out.println("Ingrese la longitud de las Aristas: ");
		Arista= lector.nextDouble();
		if(Arista<0) {
			while(Arista<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la Arista del Tetaedro:  ");
				Arista= lector.nextDouble();
			}
		}
		
		//Calculos//
		Area= Math.pow(Arista,2)*Math.sqrt(3);
		Volumen= (Math.sqrt(2)/12)*Math.pow(Arista,3);
		altura=Arista*(Math.sqrt(6))/3;
		System.out.println("El Area del Tetraedro es: "+Area+"");
		System.out.println();
		System.out.println("El Volumen de Tetraedro es: "+Volumen+"");
		System.out.println();
		System.out.println("La Altura del Tetraedro es: "+altura+"");
		}catch(Exception Tet) {
			if (Tet instanceof InputMismatchException) {
				System.out.println("Ha ingresado datos no compatibles");
				System.out.println("Vuelve a intentarlo");
			}
		}

	}
	
	
	
}
