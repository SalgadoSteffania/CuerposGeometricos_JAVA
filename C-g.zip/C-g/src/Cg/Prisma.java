package Cg;

public class Prisma {

}
