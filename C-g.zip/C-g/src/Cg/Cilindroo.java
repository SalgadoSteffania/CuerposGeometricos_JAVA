 package Cg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Cilindroo extends CuerposGeometricos {
	private  double Volumen = 0;
	private  double AL =0;
	private double AreaTotal;
	Scanner lector=new Scanner(System.in);
	private double ABase;

	

	public Cilindroo(double altura, double ABase, double radio, double PB, double AreaLateral, double area,double Volumen,double AL,double AreaTotal) {
		super(altura, ABase, radio, PB, AreaLateral, area);
		this.Volumen=Volumen;
		this.AL=AL;
		this.AreaTotal=AreaTotal;
		
	}
	

public double getVolumen() {
	return Volumen;
}



public void setVolumen(double volumen) {
	Volumen = volumen;
}



public double getAL() {
	return AL;
}



public void setAL(double aL) {
	AL = aL;
}



public double getAreaTotal() {
	return AreaTotal;
}



public void setAreaTotal(double areaTotal) {
	AreaTotal = areaTotal;
}



public Scanner getLector() {
	return lector;
}



public void setLector(Scanner lector) {
	this.lector = lector;
}



public double getABase() {
	return ABase;
}



public void setABase(double aBase) {
	ABase = aBase;
}



	/////////
	//////////


public void CalculoCilindro() {
	boolean continuar=false;
	
	do {
	
	try {
		
		
	  System.out.println("_____Cilindro_____");
		System.out.println();
		System.out.println("Ingrese el radio del cilindro:  ");
		radio = lector.nextDouble();
		if(radio<0) {
			while(radio<0) {
				System.out.println("No puede ingresar datos negativos");	
				System.out.println("Ingrese el radio del cilindro:  ");
				radio = lector.nextDouble();
			}
		}
		System.out.println();
		System.out.println("Ingrese la Altura del cilindro:  ");
		setAltura(lector.nextDouble());
		if(getAltura()<0) {
			while(getAltura()<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la Altura del cilindro:  ");
				setAltura(lector.nextDouble());
        }
		 }
	}catch (Exception e) {
		 if (e instanceof InputMismatchException) {
			 System.out.println("No puede ingresar letras");
			 System.out.println("Vuelve a intentarlo");
			
			}
		 continuar=true;
			}
	
	
}while(continuar=true);

		PB= 2*Math.PI*radio;
		AL= PB*altura;
		ABase= Math.PI*radio*radio;
		AreaTotal= 2*Math.PI*radio*(altura+radio);
		Volumen= ABase*altura;
	    
	    System.out.println("El Area Lateral del Cilindro es: "+AL+"");
		System.out.println("El Area Total del cilindro es: "+AreaTotal+"");
		System.out.println("El volumen del cilindro es: "+Volumen+"");
	
 }




}
















