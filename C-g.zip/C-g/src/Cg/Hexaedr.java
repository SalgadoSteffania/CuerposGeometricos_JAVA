package Cg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Hexaedr extends CuerposGeometricos {
	private double Diagonal;
	private double Aristas;
	private double Volumen;
	private double Area;
	
	public Hexaedr(double altura, double abase, double radio, double PB, double areaLateral, double area,double Diagonal,double Aristas,double Volumen,double Area) {
		super(altura, abase, radio, PB, areaLateral, area);
	 this.Aristas=Aristas;
	 this.Diagonal=Diagonal;
	 this.Volumen=Volumen;
		
		
	}


	
	public double getDiagonal() {
		return Diagonal;
	}



	public void setDiagonal(double diagonal) {
		Diagonal = diagonal;
	}



	public double getAristas() {
		return Aristas;
	}



	public void setAristas(double aristas) {
		Aristas = aristas;
	}



	public double getVolumen() {
		return Volumen;
	}



	public void setVolumen(double volumen) {
		Volumen = volumen;
	}



	public double getArea() {
		return Area;
	}



	public void setArea(double area) {
		Area = area;
	}

	///////
	////////////
	//////////
	



	public void CalcularHexaedro() {
		try {
		Scanner lector = new Scanner(System.in);
		
		System.out.println("�����Hexaedro�����");
		System.out.println("_________________________________________");
		System.out.println("Ingrese la longitud de las Aristas: ");
		Aristas= lector.nextDouble();
		if(Aristas<0) {
			while(Aristas<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud de las del Hexaedro:  ");
				Aristas= lector.nextDouble();
			}
		}
		Area=6*Math.pow(Aristas,2);
		Volumen= Math.pow(Aristas, 3);
		Diagonal=Aristas*Math.sqrt(3);
		System.out.println("El Area Del Hexaedro es: "+Area+"");
		System.out.println("");
		System.out.println("El Volumen Del Hexaedro es: "+Volumen+"");
		System.out.println("");
		System.out.println("La Diagonal Del Hexaedro es: "+Diagonal+"");
	
		
	}catch(Exception Hex) {
		if (Hex instanceof InputMismatchException) {
			System.out.println("No puede ingresar letras ni simbolos");
		}//if
	}//catch
	}
}
	
	
	
	
	
	
	
