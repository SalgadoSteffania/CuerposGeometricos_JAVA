package Cg;

import java.util.Scanner;

public class Dodecaedr extends CuerposGeometricos {
	private double ApotemaDelPentagono;
	private double Apotema;
	private double Aristas;
	private double Area;
	private double volumen;
	private Scanner lector;
	private Exception D;
	
	public Dodecaedr(double altura, double abase, double radio, double PB, double areaLateral, double area,double ApotemaDelPentagono,double Apotema,double Aristas,double Area,double Volumen) {
		super(altura, abase, radio, PB, areaLateral, area);
		this.Apotema=Apotema;
		this.ApotemaDelPentagono=ApotemaDelPentagono;
		this.Area=Area;
		
	
	}

	
	

	public double getApotemaDelPentagono() {
		return ApotemaDelPentagono;
	}
	public void setApotemaDelPentagono(double apotemaDelPentagono) {
		ApotemaDelPentagono = apotemaDelPentagono;
	}
	public double getApotema() {
		return Apotema;
	}
	public void setApotema(double apotema) {
		Apotema = apotema;
	}
	public double getAristas() {
		return Aristas;
	}
	public void setAristas(double aristas) {
		Aristas = aristas;
	}
	public double getArea() {
		return Area;
	}
	public void setArea(double area) {
		Area = area;
	}
	public double getVolumen() {
		return volumen;
	}
	public void setVolumen(double volumen) {
		this.volumen = volumen;
	}
	public Scanner getLector() {
		return getLector();
	}
	public void setLector(Scanner lector) {
		this.lector = lector;
	}
	public Exception getD() {
		return D;
	}
	public void setD(Exception d) {
		D = d;
	}


    

	public void CalcularDodecaedro() {
		Scanner lector=new Scanner(System.in);
		
		try {
			System.out.println("_____Dodecaedro_____");
			System.out.println("Ingrese la longitud de las Aristas: ");
			Aristas= lector.nextDouble();
			if(Aristas<0) {
				while(Aristas<0) {
					System.out.println("No puede ingresar datos negativos");
					System.out.println("Ingrese la longitud de las aristas:  ");
					Aristas= lector.nextDouble();
				}
			}
			Apotema= Math.sqrt(3*Aristas*Aristas/5);
			Area=3*Math.pow(Aristas,2)*(Math.sqrt(25)+10*Math.sqrt(5));
			Volumen=1*((15+7*Math.sqrt(5))*Math.pow(Aristas,3))/4;
			ApotemaDelPentagono=5/2*Aristas*Apotema;
			
		 System.out.println("El Area del Dodecaedro es: "+Area+"");
		 System.out.println("El Volumen Del Dodecaedro es: "+Volumen+"");
		// System.out.println("El Apotema del Pentagono Del Dodecaedro es: "+ApotemaDelPentagono+"");
		
		
		}catch(Exception D) {
			System.out.println("No puede ingresar letras ni simbolos");
			System.out.println("Vuelve a intentarlo");
		}
	}
	
	
	
	
	
	
}
