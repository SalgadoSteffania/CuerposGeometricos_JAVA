package Cg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TroncoDePiram extends CuerposGeometricos {
    private double AreaTotal;
	private double Volumen;
	private int  NDL;
	private double ApotemaPiramide;
	private double AreaDeLaBaseMenor;
	private double AreaDeLaBaseMayor;
	private double Apotema;
	private double PerimetroDBMenor;
	private double PerimetroDBMayor;
	private double baseMenor;
	private double baseMayor;
	private double ApBase;
	
	
	public TroncoDePiram(double altura, double abase, double radio, double PB, double areaLateral, double Area,
			double AreaTotal,double Volumen,double ApotemaPiramide,double AreaDeLaBaseMenor,double AreaDeLaBaseMayor,double Apotema,
		double PerimetroDBMenor,double PerimetroDBMayor,double baseMenor,double baseMayor,double ApBase) {
		super(altura, abase, radio, PB, areaLateral, Area);
	
		this.ApBase=ApBase;
		this.Apotema=Apotema;
		this.ApotemaPiramide=ApotemaPiramide;
		this.AreaDeLaBaseMayor=AreaDeLaBaseMayor;
		this.AreaDeLaBaseMenor=AreaDeLaBaseMenor;
		this.AreaTotal=AreaTotal;
		this.baseMayor=baseMayor;
		this.baseMenor=baseMenor;
		this.NDL=NDL;
		this.PerimetroDBMayor=PerimetroDBMayor;
		this.PerimetroDBMenor=PerimetroDBMenor;
		this.Volumen=Volumen;
	
		
	}


	public double getAreaTotal() {
		return AreaTotal;
	}


	public void setAreaTotal(double areaTotal) {
		AreaTotal = areaTotal;
	}


	public double getVolumen() {
		return Volumen;
	}


	public void setVolumen(double volumen) {
		Volumen = volumen;
	}


	public int getNDL() {
		return NDL;
	}


	public void setNDL(int nDL) {
		NDL = nDL;
	}


	public double getApotemaPiramide() {
		return ApotemaPiramide;
	}


	public void setApotemaPiramide(double apotemaPiramide) {
		ApotemaPiramide = apotemaPiramide;
	}


	public double getAreaDeLaBaseMenor() {
		return AreaDeLaBaseMenor;
	}


	public void setAreaDeLaBaseMenor(double areaDeLaBaseMenor) {
		AreaDeLaBaseMenor = areaDeLaBaseMenor;
	}


	public double getAreaDeLaBaseMayor() {
		return AreaDeLaBaseMayor;
	}


	public void setAreaDeLaBaseMayor(double areaDeLaBaseMayor) {
		AreaDeLaBaseMayor = areaDeLaBaseMayor;
	}


	public double getApotema() {
		return Apotema;
	}


	public void setApotema(double apotema) {
		Apotema = apotema;
	}


	public double getPerimetroDBMenor() {
		return PerimetroDBMenor;
	}


	public void setPerimetroDBMenor(double perimetroDBMenor) {
		PerimetroDBMenor = perimetroDBMenor;
	}


	public double getPerimetroDBMayor() {
		return PerimetroDBMayor;
	}


	public void setPerimetroDBMayor(double perimetroDBMayor) {
		PerimetroDBMayor = perimetroDBMayor;
	}


	public double getBaseMenor() {
		return baseMenor;
	}


	public void setBaseMenor(double baseMenor) {
		this.baseMenor = baseMenor;
	}


	public double getBaseMayor() {
		return baseMayor;
	}


	public void setBaseMayor(double baseMayor) {
		this.baseMayor = baseMayor;
	}


	public double getApBase() {
		return ApBase;
	}


	public void setApBase(double apBase) {
		ApBase = apBase;
	}

	////
	///////////////
	////////////
	
	
	public void CalcularTroncoDePiramide() {
		try {
		double AreaLateral,AreaTotal,Volumen,Altura, NDL,ApotemaPiramide;
		double AreaDeLaBaseMenor,AreaDeLaBaseMayor,Apotema,PerimetroDBMenor,PerimetroDBMayor;
		double baseMenor,baseMayor,ApBase;
		Scanner lector = new Scanner (System.in);
		
		System.out.println("_______Tronco de piramide________");
		System.out.println("_____________________________________________");
		System.out.println("Ingrese el numero de lados de la piramide: ");
		NDL =lector.nextDouble();
		if(NDL<0) {
			while(NDL<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese el numero de lado :  ");
				NDL= lector.nextDouble();
			}
		}

		System.out.println("Ingrese la longitud de los lados de la base menor: ");
		baseMenor= lector.nextDouble();
		if(baseMenor<0) {
			while(baseMenor<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud dde los lados de la base menor:  ");
				baseMenor= lector.nextDouble();
			}
		}
		System.out.println("Ingrese la longitud de los lados de la base mayor: ");
		baseMayor = lector.nextDouble();
		if(baseMayor<0) {
			while(baseMayor<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud de los lados de la basse mayor :  ");
				baseMayor= lector.nextDouble();
			}
		}
		System.out.println("Ingrese la altura: ");
		Altura= lector.nextDouble();
		if(Altura<0) {
			while(Altura<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud de la altura:  ");
				Altura= lector.nextDouble();
			}
		}
		 ApBase= NDL/2;
		 Apotema=Math.pow( Altura,2)+Math.pow(ApBase,2);
		ApotemaPiramide=Math.sqrt(Math.pow(Altura,2)+Math.pow(Apotema,2));
		PerimetroDBMenor=NDL*baseMenor;
		PerimetroDBMayor=NDL*baseMayor;
		AreaDeLaBaseMayor= (PerimetroDBMayor*Apotema)/2;
		AreaDeLaBaseMenor= (PerimetroDBMenor*Apotema)/2;

		AreaLateral=((PerimetroDBMayor + PerimetroDBMenor)*ApotemaPiramide)/2;
		AreaTotal=AreaLateral+AreaDeLaBaseMayor+AreaDeLaBaseMenor;
		Volumen=Altura*(AreaDeLaBaseMayor+AreaDeLaBaseMenor)+ Math.sqrt((AreaDeLaBaseMayor)*(AreaDeLaBaseMenor))/3   ;
		System.out.println("El Area Lateral es: "+AreaLateral+"");
		System.out.println();
		System.out.println("El Area Total es: "+AreaTotal+"");
		System.out.println();
		System.out.println("El Volumen es: "+Volumen+"");
		}catch (Exception Tp) {
			if (Tp instanceof InputMismatchException) {
				System.out.println("Loa datos ingresados son erroneos");
				System.out.println("Vuelve a intentarlo");
			}
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
