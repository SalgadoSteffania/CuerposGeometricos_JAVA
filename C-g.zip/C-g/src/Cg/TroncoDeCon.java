package Cg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TroncoDeCon extends Conoo{
	private double RadioMayor;
	private double Volumen;
	private double AreaDeLaBaseMayor;
	private double AreaDeLaBaseMenor;
	private double AreaTotal;

	public TroncoDeCon(double altura, double abase, double radio, double PB, double areaLateral, double area,
			double Generatriz, double Altura,double RadioMayor,double Volumen,double AreaDeLaBaseMayor,double AreaDeLaBaseMenor,double AreaTotal ) {
		super(altura, abase, radio, PB, areaLateral, area, Generatriz, Altura);
		this.AreaDeLaBaseMayor=AreaDeLaBaseMayor;
		this.AreaDeLaBaseMenor=AreaDeLaBaseMenor;
		this.AreaTotal=AreaTotal;
		this.RadioMayor=RadioMayor;
		this.Volumen=Volumen;
		
		
	}
	
	
	
	public double getRadioMayor() {
		return RadioMayor;
	}



	public void setRadioMayor(double radioMayor) {
		RadioMayor = radioMayor;
	}



	public double getVolumen() {
		return Volumen;
	}



	public void setVolumen(double volumen) {
		Volumen = volumen;
	}



	public double getAreaDeLaBaseMayor() {
		return AreaDeLaBaseMayor;
	}



	public void setAreaDeLaBaseMayor(double areaDeLaBaseMayor) {
		AreaDeLaBaseMayor = areaDeLaBaseMayor;
	}



	public double getAreaDeLaBaseMenor() {
		return AreaDeLaBaseMenor;
	}



	public void setAreaDeLaBaseMenor(double areaDeLaBaseMenor) {
		AreaDeLaBaseMenor = areaDeLaBaseMenor;
	}



	public double getAreaTotal() {
		return AreaTotal;
	}



	public void setAreaTotal(double areaTotal) {
		AreaTotal = areaTotal;
	}



	public void CalcularTroncoDeCono() {
		
		try {
		Scanner lector =new Scanner(System.in);
		System.out.println("______Tronco De Cono_____");
		System.out.println("________________________");
		System.out.println( "Ingrese la Altura: ");
		Altura = lector.nextDouble();
		if(Altura<0) {
			while(Altura<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la Altura:  ");
				Altura= lector.nextDouble();
			}
		}
		System.out.println("Ingrese la longitud del radio: ");
		radio= lector.nextDouble();
		if(radio<0) {
			while(radio<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud del radio:  ");
				radio= lector.nextDouble();
			}
		}
		System.out.println("Ingrese el Radio Mayor: ");
		RadioMayor= lector.nextDouble();
		if(RadioMayor<0) {
			while(RadioMayor<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud del Radio Mayor:  ");
				RadioMayor= lector.nextDouble();
			}
		}
//calculos
		Generatriz=Math.sqrt(Math.pow(Altura, 2)+Math.pow(radio, 2));
		AreaLateral= Math.PI*Generatriz*(RadioMayor+radio);
		AreaDeLaBaseMenor=Math.PI*Math.pow(radio,2);
		AreaDeLaBaseMayor=Math.PI*Math.pow(RadioMayor, 2);
		AreaTotal=AreaLateral+AreaDeLaBaseMayor+AreaDeLaBaseMenor;
		Volumen=(Math.PI*Altura*Math.pow(RadioMayor, 2)+Math.pow(radio, 2)+RadioMayor*radio)/3;
		System.out.println("El Area  Lateral es: "+AreaLateral+"");
		System.out.println("���������������������������������������");
		System.out.println("El Area Total es: "+AreaTotal+"");
		System.out.println("���������������������������������������");
		System.out.println("El Volumen es: "+Volumen+"");
		}catch (Exception Tc) {
			if (Tc instanceof InputMismatchException) {
				System.out.println("Los datos que ingreso , no son compatibles");
				System.out.println("Vuelve a intentarlo");
			}
		}
		
		
	}

	
	

}
