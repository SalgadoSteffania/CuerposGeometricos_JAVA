package Cg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Esferaa extends CuerposGeometricos {

	private double radio2;
	private double Radio1;
	private double RadioMayor;
	private double Altura;
	private double AreaZ;
	private double VolumenE;
	private double VolumenC;
	

	public Esferaa(double altura, double abase, double radio, double PB, double areaLateral, double area, double radio2,double Radio1,double RadioMayor,double Altura,double AreaZ,double VolumenE,double VolumenC) {
		super(altura, abase, radio, PB, areaLateral, area);
		this.Altura=Altura;
		this.AreaZ=AreaZ;
		this.Radio1=Radio1;
		this.radio2=radio2;
		this.RadioMayor=RadioMayor;
		this.VolumenC=VolumenC;
		this.VolumenE=VolumenE;
		
	}


	public double getRadio2() {
		return radio2;
	}


	public void setRadio2(double radio2) {
		this.radio2 = radio2;
	}


	public double getRadio1() {
		return Radio1;
	}


	public void setRadio1(double radio1) {
		Radio1 = radio1;
	}


	public double getRadioMayor() {
		return RadioMayor;
	}


	public void setRadioMayor(double radioMayor) {
		RadioMayor = radioMayor;
	}


	public double getAltura() {
		return Altura;
	}


	public void setAltura(double altura) {
		Altura = altura;
	}


	public double getAreaZ() {
		return AreaZ;
	}


	public void setAreaZ(double areaZ) {
		AreaZ = areaZ;
	}


	public double getVolumenE() {
		return VolumenE;
	}


	public void setVolumenE(double volumenE) {
		VolumenE = volumenE;
	}


	public double getVolumenC() {
		return VolumenC;
	}


	public void setVolumenC(double volumenC) {
		VolumenC = volumenC;
	}

	
	///////
/////////////////
	public void CalcularEsfera() {
		try {
			Scanner lector = new Scanner (System.in);
			double Area,Volumen,radio;
			System.out.println("_____Esfera_____");
			System.out.println("_________________________________");
			System.out.println("Ingrese el radio de la esfera");
			radio= lector.nextDouble();
			if(radio<0) {
				while(radio<0) {
					System.out.println("No puede ingresar datos negativos");
					System.out.println("Ingrese la longitud del radio:  ");
					radio= lector.nextDouble();
				}
			}
			Area=4*Math.PI*Math.pow(radio,2);
			Volumen=4*Math.PI*Math.pow(radio,3)/3;
		System.out.println("El Area De La Esfera es: "+Area+" ");
		System.out.println("El Volumen De La Esfera es: "+Volumen+"");
		System.out.println("////////////////////////////////////////////////////////");
		System.out.println();
		
		double radio2 = 0,Radio1,RadioMayor,altura,Altura,AreaZ,VolumenE,VolumenC;
		
		System.out.println("Casquete Esferico");
		System.out.println("Ingrese el Radio Mayor del Casquete Esferico: ");
		RadioMayor= lector.nextDouble();
		if(RadioMayor<0) {
			while(RadioMayor<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese el Radio Mayor del Casquete Esferico:  ");
				RadioMayor= lector.nextDouble();
			}
		}
		
		System.out.println("Ingrese la altura Del Casquete Esferico: ");
		altura= lector.nextDouble();
		if(altura<0) {
			while(altura<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud de la altura:  ");
				altura= lector.nextDouble();
			}
		}
		System.out.println("Zona Esferica");
		System.out.println("Ingrese el Radio Pisma de la ZonaEsferica: ");
		Radio1= lector.nextDouble();
		if(Radio1<0) {
			while(Radio1<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud del Radio1:  ");
				Radio1= lector.nextDouble();
			}
		}
		System.out.println("Ingrese el Radio de la ZonaEsferica");
		Altura= lector.nextDouble();
		if(	Altura<0) {
			while(Altura<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud del radio:  ");
				Altura= lector.nextDouble();
			}
		}
		
		
				System.out.println("_________________________________________________________-");
				System.out.println();
			
		AreaZ=2*Math.PI*RadioMayor*Altura;
		VolumenE=(Math.PI*Altura*(Math.pow(Altura, 2)+3*Math.pow(radio2, 2)+3*Math.pow(Radio1,2)))/6;
		VolumenC=(Math.PI*Math.pow(Altura,2)*(3*RadioMayor-Altura))/3;
		
		System.out.println("El Area De La ZonaEsfera es: "+AreaZ+" ");
		System.out.println("El Volumen Del Casquete Esferico es: "+VolumenC+"");
		
			
		
		}catch(Exception E) {
			if(E instanceof InputMismatchException) {
				System.out.println("Ingrese el valor que se le pide,No puede ingresar letras ni simbolos");
			}
			
		}
	}
	
}
