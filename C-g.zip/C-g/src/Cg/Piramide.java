package Cg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Piramide extends Prismaa {
 private int NDL;
 private double ApBs;
 private double AreaDeLaBase;
 private double AreaTotal;
 private double Abase;
	
	public Piramide(double altura, double abase, double radio, double PB, double areaLateral, double area,
			double PerimetroDELaBase, double Volumen, double NumeroDeLados, int nl, double Apotema, double longitud, double ApBs) {
		
		super(altura, abase, radio, PB, areaLateral, area, PerimetroDELaBase, Volumen, NumeroDeLados, nl, Apotema, longitud);
		
		this.Abase=Abase;
		this.ApBs=ApBs;
		this.AreaDeLaBase=AreaDeLaBase;
		this.AreaTotal=AreaTotal;
		this.NDL=NDL;
	}
	
	public void CalcularPiramide() {
		try {

		Scanner lector =new Scanner(System.in);
		
		System.out.println("______Piramide_____");
		System.out.println("____________________________________________");
		System.out.println("Ingrese el numero de lados de la piramide: ");
		NDL =lector.nextInt();
		if(NDL<0) {
			while(NDL<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud:  ");
				NDL= lector.nextInt();
			}
		}
		System.out.print("Ingrese la longitud de los lados de la piramide: ");
		longitud= lector.nextDouble();
		if(longitud<0) {
			while(longitud<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud:  ");
				longitud= lector.nextDouble();
			}
		}
		System.out.print("Ingrese la Altura de la piramide: ");
		altura= lector.nextDouble();
		if(altura<0) {
			while(altura<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud de la Altura:  ");
				altura= lector.nextDouble();
			}
		}
		//calculos
		PB=NDL*longitud;
		ApBs= NDL/2;
		 Apotema=Math.pow( altura,2)+Math.pow(ApBs,2);
		 AreaDeLaBase= NDL*longitud*ApBs;
		 AreaLateral=PB*Apotema/2;
		 AreaTotal= AreaLateral+AreaDeLaBase;
			Volumen= AreaDeLaBase*altura/3;
		System.out.println("El Area lateral de la piramide  es: "+AreaLateral+"");
	System.out.println("����������������������������������������������������������");
	System.out.println("El Area Total del Prisma es: "+AreaTotal+"");
	System.out.println("����������������������������������������������������������");
	System.out.println("El volumen del Prisma es: "+Volumen+"");
		}catch(Exception Pi) {
			if (Pi instanceof InputMismatchException) {
				System.out.println("Los datos ingresados no son correctos");
			}
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	

}
