package Cg;

import java.util.Scanner;

public class Prismaa extends CuerposGeometricos{
private double  PerimetroDeLaBase;
public double Volumen;
private double NumeroDeLados=5;
private int nl;
public double Apotema;
protected double longitud;

	
	
	
	public Prismaa(double altura, double abase, double radio, double PB, double areaLateral, double area,double PerimetroDELaBase,double Volumen,double NumeroDeLados,int nl,double Apotema,double longitud) {
		super(altura, abase, radio, PB, areaLateral, area);
		this.Apotema=Apotema;
		this.longitud=longitud;
		this.nl=nl;
		this.NumeroDeLados=NumeroDeLados;
		this.PerimetroDeLaBase=PerimetroDeLaBase;
		this.Volumen=Volumen;
	}




	//Getteer y Setters//


	public double getPerimetroDeLaBase() {
		return PerimetroDeLaBase;
	}




	public void setPerimetroDeLaBase(double perimetroDeLaBase) {
		PerimetroDeLaBase = perimetroDeLaBase;
	}




	public double getVolumen() {
		return Volumen;
	}




	public void setVolumen(double volumen) {
		Volumen = volumen;
	}




	public double getNumeroDeLados() {
		return NumeroDeLados;
	}




	public void setNumeroDeLados(double numeroDeLados) {
		NumeroDeLados = numeroDeLados;
	}




	public int getNl() {
		return nl;
	}




	public void setNl(int nl) {
		this.nl = nl;
	}




	public double getApotema() {
		return Apotema;
	}




	public void setApotema(double apotema) {
		Apotema = apotema;
	}




	public double getLongitud() {
		return longitud;
	}




	public void setLongitud(double longitud) {
		this.longitud = longitud;
	}
	
	/////
	//////
	//////////
	public void PrismaCalculo() {
		try{
		Scanner lector=new Scanner(System.in);
		int nl;
		double  AreaLateral;
		double AreaTotal;
		 double PerimetroDeLaBase, Volumen, NumeroDeLados=5;
		double Apotema,Altura,longitud,AreaDeLaBase;
		System.out.println("Prisma");
		System.out.println("Calculo del Area Lateral");
		System.out.println("Ingrese la longitud de los lados: ");
		longitud = lector.nextDouble();
		if(longitud<0) {
			while(longitud<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud:  ");
				longitud= lector.nextDouble();
			}
		}
		System.out.println("Ingrese la Altura del prisma: ");
		Altura = lector.nextDouble(); 
		if(Altura<0) {
			while(Altura<0) {
				System.out.println("No puede ingresar datos negativos");
				System.out.println("Ingrese la longitud:  ");
				Altura= lector.nextDouble();
			}
		}
		//Calculos//
		PerimetroDeLaBase= NumeroDeLados * longitud;
		AreaLateral =(PerimetroDeLaBase*Altura);
		Apotema= Math.sqrt(3*longitud*longitud/4);
		AreaDeLaBase =(PerimetroDeLaBase*Apotema/2);
		AreaTotal = AreaLateral + 2*AreaDeLaBase;
		Volumen= AreaDeLaBase * Altura;
		
		System.out.println("El Area Lateral del prisma es: "+AreaLateral+" ");
		System.out.println("��������������������������");
	System.out.println("El Area Total del prisma es: "+AreaTotal+" ");
	System.out.println("��������������������������");
	System.out.println("El volumen del prisma es: "+Volumen+" ");
	
		}catch(Exception M) {
			System.out.println("No puede ingresar letras ni simbolos");
			System.out.println("Vuelve a intentarlo");
		}
		
	}



	
	
	
	
 
}
