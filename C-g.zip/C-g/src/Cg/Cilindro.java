package Cg;

public class Cilindro extends CuerposGeometricos  {

	private static final int Altura = 0;
	private double Volumen;
	private double AreaTotal;
	private double AL;
	
	public Cilindro(double altura,double Abase,double radio,double PB,double  AreaLateral,double Area) {
		super(altura,Abase,radio,PB,AreaLateral,Area);
		this.AL=AL;
		this.AreaTotal=AreaTotal;
		this.Volumen=Volumen;
	}
	
	
	
	public double getVolumen() {
		return Volumen;
	}



	public void setVolumen(double volumen) {
		Volumen = volumen;
	}



	public double getAreaTotal() {
		return AreaTotal;
	}



	public void setAreaTotal(double areaTotal) {
		AreaTotal = areaTotal;
	}



	public double getAL() {
		return AL;
	}



	public void setAL(double aL) {
		AL = aL;
	}



	public double getAltura() {
		return Altura;
	}

//////
	////////////
	////////////

	System.out.println("_____Cilindro_____");
	System.out.println();
	System.out.println("Ingrese el radio del cilindro:  ");
	radio = lector.nextDouble();
	if(radio<0) {
		while(getRadio()<0) {
			System.out.println("No puede ingresar datos negativos");	
			System.out.println("Ingrese el radio del cilindro:  ");
			radio = lector.nextDouble();
		}
	}
	System.out.println();
	System.out.println("Ingrese la Altura del cilindro:  ");
	Altura= lector.nextDouble();
	if(Altura<0) {
		while(Altura<0) {
			System.out.println("No puede ingresar datos negativos");
			System.out.println("Ingrese la Altura del cilindro:  ");
			Altura= lector.nextDouble();
      }
	 }

	public void CalcularAL() {
		setPB(2*Math.PI*getRadio());
		AL= getPB()*getAltura();
	}
	
	
	
	
	
	
}
