package Cg;

import java.util.Scanner;

public class APP {

	
	static Scanner lector=new Scanner(System.in);
	public static void main(String[] args) {
		
		int opcion = 0;
		boolean	continuar=false;
		
		do {
			
			do {
				
			
			
			try {
		
				
			int opciones;
			System.out.println();
			System.out.println("_________________________Bienveni@ a: CALCULO DE FIGURAS GEOMETRICAS_________________________");
			System.out.println();
			System.out.println("Ingrese la figura Geometrica que desea: ");
			System.out.println();
			System.out.println("1: Cilindro");
			System.out.println("2: Cono");
			System.out.println("3: Prisma");
			System.out.println("4: Dodecaedro");
			System.out.println("5: Esfera");
			System.out.println("6: Hexaedro");
			System.out.println("7: Icosaedro");
			System.out.println("8: Octaedro");
			System.out.println("9: Ortoedro");
			System.out.println("10: Piramide");
			System.out.println("11: Tetraedro");
			System.out.println("12: Tronco De Cono");
			System.out.println("13: Tronco De Piramide");
			System.out.println();
			
			opciones = lector.nextInt(); 
			if(opciones>14) {
				while(opciones>14) {
					System.out.println("Error");
					System.out.println("Ingrese un valor del rango 1-14");
					opciones=lector.nextInt();
				}
			}else {
				if(opciones<1) {
				while(opciones<1) {
					System.out.println("Error");
					System.out.println("Ingrese un valor del rango 1-14");
					opciones=lector.nextInt();
				}
				}
			}
			//////////
			/////////
			switch (opciones) {
			
			case 1:
				Cilindroo cilindroo =new Cilindroo(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
				 cilindroo.CalculoCilindro();
				 break;
				 
			case 2:
				Conoo conoo=new Conoo(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
				 conoo.CalcularCono();
				 break;
				 
			case 3:
				Prismaa prisma=new Prismaa(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0.0,0.0);
				prisma.PrismaCalculo();
				break;
			
			case 4:
				Dodecaedr dodecaedr=new Dodecaedr(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
				dodecaedr.CalcularDodecaedro();
				break;
				
			case 5:
			  Esferaa esferaa=new Esferaa(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);	
			 esferaa.CalcularEsfera();
			 break;
			 
			case 6:
				Hexaedr hexaedr=new Hexaedr(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
				hexaedr.CalcularHexaedro();
				break;
				
			/*case 7:
				HusoEsf husoesf= HusoEsf(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
				husoesf.CalcularHusoEsferico();
			break;*/
			
			case 7:
				Icosaedro icosaedro=new Icosaedro(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
				icosaedro.CalcularIcosaedro();
				break;
				
			case 8:
				Octaedro octaedro=new Octaedro(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
			    octaedro.CalcularOctaedro();
			    break;
			    
			case 9:
				
			Ortoedro ortoedro=new Ortoedro(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
			ortoedro.CalcularOrtoedro();
			break;
			
			
			case 10:
				Piramide piramide=new Piramide(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0,0.0,0.0,0.0);
				piramide.CalcularPiramide();
			break;
			
			case 11:
				Tetraedro tetraedro=new Tetraedro(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
				tetraedro.CalcularTetraedro();
				break;
				
			case 12:
				TroncoDeCon troncodecon=new TroncoDeCon(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
				troncodecon.CalcularTroncoDeCono();
				break;
				
			case 13:
				TroncoDePiram troncodepiram=new TroncoDePiram(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
				troncodepiram.CalcularTroncoDePiramide();
				break;

			}
		}catch (Exception a) {
			System.out.println("Error, no puede ingresar letras ni simbolos");
			continuar=false;
			
		}
			
//	}
	}while(continuar);
			
			
		Scanner lector=new Scanner(System.in);
		//int opcion1;
		System.out.println();
		System.out.println();
	System.out.println("Opcion 1: Continuar con el programa");
	System.out.println("Opcion 2: Salir del programa");
	System.out.print("Opcion : ");
	opcion = lector.nextInt();
	if (opcion <= 0) {
			while (opcion<= 0) {
				System.out.println("Ha ingresado una opcion invalida");
				System.out.print("Opcion : ");
				opcion = lector.nextInt();
				while (opcion >= 3) {
					System.out.println("Usted ha ingresado una opcion invalida, favor ingrese una opcion valida");
					System.out.print("Opcion : ");
					opcion = lector.nextInt();
				}
			}

	}
	else{
		while (opcion>= 3) {
			System.out.println("Usted ha ingresado una opcion invalida, favor ingrese una opcion valida");
			System.out.print("Opcion : ");
			opcion= lector.nextInt();
			while (opcion<= 0) {
				System.out.println("Usted ha ingresado una opcion invalida, favor ingrese una opcion valida");
				System.out.print("Opcion : ");
				opcion= lector.nextInt();
			}
		}
	}
	if(opcion==2) {
		System.out.println("Gracias por utilizar el programa");
		System.out.println();
	}
			

		
		}while(opcion == 1);
	
		
		
	}
	

}
